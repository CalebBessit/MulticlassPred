
# CSC4025Z: AI Assignment 1

The structure of this directory is as follows:

```script
.
├── analysis_scripts/     -> Contains scripts to analyse data and results
├── data/                 -> Should contain the data
├── models_and_training/  -> Contains all model code and scripts for training models
├── preprocessing         -> Contains scripts for downloading code, doing some preprocessing and initial analysis
├── tuning/               -> Contains scripts which were used to tune the autoencoder architecture and do hyperparameter tuning
├── utils.py              -> Contains helper functions and constants
└── requirements.txt
```

We include a sample of the dataset in the `data/` directory.

To run the code, please begin by installing the required files (suitable for Windows 10):

```
> pip install -r requirements.txt
```

Then, run the files from the top-level directory in the following order to do the following steps:

1. Download the dataset from Kaggle
2. Run initial genre analysis and generate labelled genre data.
3. Create train/test split. You should also update the `VERSION` flag in `setup.py` to "genre" and rerun the `data_preprocessing.py` script to regenerate the data for genre prediction.
4. Train and test the MLP, Logistic regression and autoencoder models.
5. Train and test the KNN model.
6. Construct, train and run the Naive Bayes model.
7. Run scripts for architectural and hyperparameter tuning.

```
> python preprocessing/download_dataset.py
> python preprocessing/data_analysis.py
> python -m preprocessing.data_preprocessing
> python -m models_and_training.MLP_LogReg_AE
> python -m models_and_training.KNN
> python -m models_and_training.naiveBayes
> python -m tuning.arch_tuning
> python -m tuning.arch_tuning_subsets
> python -m tuning.hyperparam_tuning_py
```




