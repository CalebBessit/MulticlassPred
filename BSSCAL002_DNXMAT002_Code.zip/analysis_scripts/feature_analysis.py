# Analysing feature correlation to determine what features can be dropped in model
# Caleb Bessit
# 22 October 2025

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Params
X_train_p = pd.read_csv("train.csv")
X_train_g = pd.read_csv("train_genre.csv")


version = "popularity"
features_p = [ 'year', 'danceability', 'energy', 'key', 'loudness', 'mode',
        'speechiness', 'acousticness', 'instrumentalness', 'liveness',
        'valence', 'tempo', 'duration_ms', 'time_signature','popularity']

features_g = [ 'year', 'danceability', 'energy', 'key', 'loudness', 'mode',
        'speechiness', 'acousticness', 'instrumentalness', 'liveness',
        'valence', 'tempo', 'duration_ms', 'time_signature','popularity','genre']

attributes_p = X_train_p[features_p]
attributes_g = X_train_g[features_g]

# Correlation matrix

corr_p = attributes_p.corr()
corr_g = attributes_g.corr()

corr_p["popularity"].sort_values(ascending=False)
corr_g["genre"].sort_values(ascending=False)





# Considering pairs
print(f"\n=== Popularity ===")
corr_p_pairs = corr_p.unstack()
postive_corr_p = corr_p_pairs[(corr_p_pairs>=0.5) & (corr_p_pairs<1)]
print(f"Highly correlated pairs: \n{postive_corr_p}")

negative_corr_p = corr_p_pairs[(corr_p_pairs<=-0.5) & (corr_p_pairs>-1)]
print(f"Negatively correlated pairs: \n{negative_corr_p}")

# For genre
print(f"\n=== Genre ===")
corr_g_pairs = corr_g.unstack()
postive_corr_g = corr_g_pairs[(corr_g_pairs>=0.5) & (corr_g_pairs<1)]
print(f"Highly correlated pairs for genre: \n{postive_corr_g}")

negative_corr_g = corr_g_pairs[(corr_g_pairs<=-0.5) & (corr_g_pairs>-1)]
print(f"Negatively correlated pairs for genre: \n{negative_corr_g}")


cmap = sns.diverging_palette(230,20, as_cmap=True)

plt.figure("Popularity")
sns.heatmap(corr_p, annot=True, fmt='.1g', vmin=-1, vmax=1, center=0, cmap=cmap)
plt.title("Popularity Correlation Matrix", fontweight='bold', fontsize='large')

plt.figure("Genre")
sns.heatmap(corr_g, annot=True, fmt='.1g', vmin=-1, vmax=1, center=0, cmap=cmap)
plt.title("Genre Correlation Matrix", fontweight='bold', fontsize='large')

plt.show()