# Analyses the results from hyperparameter tuning and prints the best results for all cases tested
# Caleb Bessit
# 21 October 2025

import os
import pandas as pd

descrips = ["Popularity (3 classes)", "Popularity (5 classes)", "Genre prediction"]

file_names = ["popularity_3","popularity_5","genre_5"]

subsets = ['structural', 'physical','perceptual','metadata']

metrics = ["val_loss","test_accuracy","test_f1","test_bal_acc","train_time_sec"]
metric_index = 0

# Genre subsets

print(f"\n=========== HYPERPARAM RESULTS ==========")
for file in file_names:
    print(f"\n\t + For {file}:")
    data = pd.read_csv( os.path.join(f"full_results/autoencoder_dynamic_{file}_classes.csv") )

    data = data.sort_values(by= metrics[metric_index])
    print(data.head())


print(f"\n=========== HYPERPARAM RESULTS  OTHER ==========")

for subset in subsets:
    print(f"\n == USING {subset}")
    for file in file_names:
        print(f"\n\t + For {file}:")
        data = pd.read_csv( os.path.join(f"full_results/autoencoder_dynamic_{file}_classes_{subset}.csv") )

        data = data.sort_values(by= metrics[metric_index])
        print(data.head())


