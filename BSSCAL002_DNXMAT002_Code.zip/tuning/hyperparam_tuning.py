# Hyperparameter tuning for dynamic training parameters
# ChatGPT and Caleb Bessit
#  |→ Boilerplate and cleaning up done by ChatGPT, logic and decisions done by Caleb Bessit
# 23 October 2025

import os, itertools, csv, time, argparse, fcntl
import numpy as np
from tensorflow.keras import layers, models, callbacks, optimizers
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from utilities import load_data_exp, calculate_weights, classification_metrics



parser = argparse.ArgumentParser(description="Tune epochs, batch size, and LR for best autoencoders.")
parser.add_argument("--results_dir", type=str, default="/scratch/bsscal002/ai_results", help="Path to results directory.")
parser.add_argument("--start", type=int, default=0)
parser.add_argument("--end", type=int, default=None)
args = parser.parse_args()


best_architectures = {
    # 3-class popularity prediction
    ("popularity", 3): {"hidden_sizes": [32], "latent_dim": 32, "activation": "relu"},
    # 5-class popularity prediction
    ("popularity", 5): {"hidden_sizes": [64], "latent_dim": 16, "activation": "relu"},
    # Genre classification (5-class)
    ("genre", 5): {"hidden_sizes": [64], "latent_dim": 16, "activation": "relu"}
}

# Serach space
epochs_list = [10,30, 50, 100]
batch_sizes = [32, 64, 128]
learning_rates = [1e-4, 5e-4, 1e-3, 5e-3]

param_grid = list(itertools.product(epochs_list, batch_sizes, learning_rates))

def build_autoencoder(input_dim, hidden_sizes, latent_dim, activation, learning_rate):
    encoder = models.Sequential([layers.Input(shape=(input_dim,))])
    for h in hidden_sizes:
        encoder.add(layers.Dense(h, activation=activation))
    encoder.add(layers.Dense(latent_dim, activation=activation))

    decoder = models.Sequential([layers.Input(shape=(latent_dim,))])
    for h in reversed(hidden_sizes):
        decoder.add(layers.Dense(h, activation=activation))
    decoder.add(layers.Dense(input_dim))

    autoencoder = models.Sequential([encoder, decoder])
    autoencoder.compile(
        optimizer=optimizers.Adam(learning_rate=learning_rate),
        loss='mse'
    )
    return autoencoder, encoder

# Subsets
metadata   = ['year', 'duration_ms']
physical   = ['loudness','tempo','instrumentalness','speechiness','liveness']
perceptual = ['danceability','energy','valence','acousticness']
structural = ['key','mode','time_signature']

os.makedirs(args.results_dir, exist_ok=True)

for (target, num_classes), arch in best_architectures.items():
    non_target = "genre" if target == "popularity" else "popularity"
    subset_name = "all_features"
    results_file = os.path.join(args.results_dir, f"autoencoder_dynamic_{target}_{num_classes}_classes_metadata.csv")

    # create results file if needed
    if not os.path.exists(results_file):
        with open(results_file, "w", newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                "epochs", "batch_size", "learning_rate",
                "hidden_sizes", "latent_dim", "activation",
                "val_loss", "test_accuracy", "test_f1", "test_bal_acc", "train_time_sec"
            ])

    def safe_write_row(path, row):
        with open(path, "a", newline='\n') as f:
            fcntl.flock(f, fcntl.LOCK_EX)
            writer = csv.writer(f)
            writer.writerow(row)
            fcntl.flock(f, fcntl.LOCK_UN)

    print(f"\n===== Tuning for {target} ({num_classes}-class) using {subset_name} =====")
    # load all features (metadata + all others)
    full_features = metadata+ [non_target]

    if target == "popularity":
        X_train, y_train = load_data_exp("train", num_classes, metadata, target)
        X_test, y_test   = load_data_exp("test",  num_classes, metadata, target)
    else:
        X_train, y_train = load_data_exp("train_genre", num_classes, metadata, target)
        X_test, y_test   = load_data_exp("test_genre",  num_classes, metadata, target)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled  = scaler.transform(X_test)
    input_dim = X_train.shape[1]

    # Restrict by args.start / end if running in parallel
    total_configs = len(param_grid)
    start = args.start
    end = args.end if args.end is not None else total_configs
    subset_configs = param_grid[start:end]

    for i, (epochs, batch_size, lr) in enumerate(subset_configs, start=start+1):
        print(f"\n[{i}/{total_configs}] epochs={epochs}, batch_size={batch_size}, lr={lr:.4e}")

        autoencoder, encoder = build_autoencoder(
            input_dim, arch["hidden_sizes"], arch["latent_dim"], arch["activation"], lr
        )

        early_stop = callbacks.EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)

        start_time = time.time()
        hist = autoencoder.fit(
            X_train_scaled, X_train_scaled,
            epochs=epochs, batch_size=batch_size,
            validation_split=0.125, verbose=0,
            callbacks=[early_stop]
        )
        train_time = time.time() - start_time
        val_loss = float(np.min(hist.history["val_loss"]))

        X_train_encoded = encoder.predict(X_train_scaled, verbose=0)
        X_test_encoded = encoder.predict(X_test_scaled, verbose=0)

        class_head = MLPClassifier(hidden_layer_sizes=(64, 32), random_state=0, max_iter=500)
        class_weights, sample_weights = calculate_weights(y_train)
        clf_pipeline = Pipeline([("scaler", StandardScaler()), ("mlp", class_head)])
        clf_pipeline.fit(X_train_encoded, y_train, mlp__sample_weight=sample_weights)

        y_pred = clf_pipeline.predict(X_test_encoded)
        metrics = classification_metrics(y_test, y_pred)

        row = [
            epochs, batch_size, lr,
            arch["hidden_sizes"], arch["latent_dim"], arch["activation"],
            round(val_loss, 6), round(metrics["accuracy"], 4),
            round(metrics["f1"], 4), round(metrics["balanced_accuracy"], 4),
            round(train_time, 2)
        ]
        safe_write_row(results_file, row)

        print(f" -> val_loss={val_loss:.4f}, acc={metrics['accuracy']:.3f}, f1={metrics['f1']:.3f}, bal_acc={metrics['balanced_accuracy']:.3f}, time={train_time/60:.1f} min")

    print(f"Finished tuning for {target} ({num_classes}-class). Results saved to {results_file}")
