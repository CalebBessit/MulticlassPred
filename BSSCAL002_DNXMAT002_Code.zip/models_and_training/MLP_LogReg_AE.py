# Creates and trains an MLP and XGBoost model
# Caleb Bessit
# 14 October 2025

import os
import time
import numpy as np
from xgboost import XGBClassifier
from sklearn.pipeline import Pipeline
from tensorflow.keras import layers, models
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import LogisticRegression
from utils import load_data, classification_metrics, calculate_weights, VERSION



# Params
NUM_CLASSES = 5

if VERSION=="popularity":
    X_train, y_train = load_data("train", NUM_CLASSES)
    X_test, y_test   = load_data("test", NUM_CLASSES)
elif VERSION=="genre":
    X_train, y_train = load_data("train_genre", NUM_CLASSES)
    X_test, y_test   = load_data("test_genre", NUM_CLASSES)

print(f"Using {VERSION} as target.")

# xgb = XGBClassifier(random_state=0)
mlp = MLPClassifier(random_state=0, max_iter=1000)

#Used for XGBoost, because model expects labels starting from zero (which we have removed)
le = LabelEncoder()

# MLP
print(f"\nCalculating sample weights for MLP...")
class_weights, sample_weights = calculate_weights(y_train)
print(f"Training and testing MLP...")
start = time.time_ns()

mlp_pl = Pipeline([
    ("scaler", StandardScaler()),
    ("mlp", mlp)
])

# MLP does not directly support handling class imbalance. Have to calculate class weights and pass it in.

mlp_pl.fit(X_train, y_train, mlp__sample_weight=sample_weights)
y_pred = mlp_pl.predict(X_test)

classification_metrics(y_test, y_pred)

print(f"MLP took {(time.time_ns()-start)*(10**-9)} seconds to train.")


# Logistic regression model

print("~~~~ LOGISTIC REGRESSION ~~~~")
print(f"\n\t + Training and testing Logistic regression model...")
start = time.time_ns()
pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("logreg", LogisticRegression( class_weight='balanced',random_state=0))
    ])

pipeline.fit(X_train, y_train)
y_pred = pipeline.predict(X_test)
classification_metrics(y_test, y_pred)

print(f"\t + Logistic regression took {(time.time_ns()-start)*(10**-9)} seconds to train.")



# Autoencoder model: code courtesy of ChatGPT but based on my honours project.
# The idea is to train an encoder and decoder in an unsupervised fashion to reconstruct the features, and then train an MLP head on the encoded features
# An interesting analysis would be to run a k-means clustering algorithm on the encoded representations to see how pure the clusters of points are

# input_dim = X_train.shape[1]
# latent_dim = 16

# # Encoder
# encoder = models.Sequential([
#     layers.Input(shape=(input_dim,)),
#     layers.Dense(64, activation='relu'),
#     layers.Dense(latent_dim, activation='relu')
# ])

# # Decoder
# decoder = models.Sequential([
#     layers.Input(shape=(latent_dim,)),
#     layers.Dense(64, activation='relu'),
#     layers.Dense(input_dim)
# ])

# # Autoencoder
# autoencoder = models.Sequential([encoder, decoder])
# autoencoder.compile(optimizer='adam', loss='mse')

# # Can tune these params, and I should scale the inputs before training
# scaler = StandardScaler()
# X_train_scaled = scaler.fit_transform(X_train)
# X_test_scaled  = scaler.transform(X_test)


# print("~~~~ AUTOENCODER ~~~~")
# print("\n\t + Training autoencoder for feature reconstruction...")
# start = time.time_ns()
# autoencoder.fit(X_train_scaled, X_train_scaled, epochs=3, batch_size=32, validation_split=0.125) #Validation data will be 10% of total data (because we assigned 80% of data for training, so 12.5% of 80% of original data is 10% of the original data)

# print(f"\t = Autoencoder training took {(time.time_ns()-start)*(10**-9)} seconds to train.")


# # Encode your data
# print("\t + Extracting encoder representations for training data...")
# X_train_encoded = encoder.predict(X_train_scaled)

# print("\t + Extracting encoder representations for test data...")
# X_test_encoded = encoder.predict(X_test_scaled)

# os.makedirs("latent_reps",exist_ok=True)
# np.save(f"latent_reps/training_reps_{NUM_CLASSES}_classes_{VERSION}.npy",X_train_encoded)
# np.save(f"latent_reps/test_reps_{NUM_CLASSES}_classes_{VERSION}.npy",X_test_encoded)

# # Train an MLP classification head on encoded representations

# class_head = MLPClassifier(random_state=0, max_iter=1000)
# # MLP classification head
# print(f"\t + Calculating sample weights for MLP...")
# class_weights, sample_weights = calculate_weights(y_train)
# print(f"\t + Training classification head...")
# start = time.time_ns()

# class_head_pl = Pipeline([
#     ("scaler", StandardScaler()),
#     ("class_head", class_head)
# ])

# # MLP does not directly support handling class imbalance. Have to calculate class weights and pass it in.

# class_head_pl.fit(X_train_encoded, y_train, class_head__sample_weight=sample_weights)

# print(f"\t = Classification head training took {(time.time_ns()-start)*(10**-9)} seconds to train.")

# y_pred = class_head_pl.predict(X_test_encoded)

# classification_metrics(y_test, y_pred)
