# Data analysis of spotify data
# Caleb Bessit
# 15 Octobet 2025

import pandas as pd
import numpy as np
import matplot2tikz
from collections import Counter
import matplotlib.pyplot as plt


data = pd.read_csv("data/spotify_data.csv")
data = data.dropna()

top_five_genres = ['acoustic','ambient','black-metal','gospel','alt-rock']
top_10 = ['acoustic','ambient','black-metal','gospel','alt-rock','emo','indian','k-pop','new-age','blues']
bott_10 = ['metalcore','pop','punk','sad','house','chicago-house','dubstep','detroit-techno','rock','songwriter']





replacements = {genre:top_five_genres.index(genre) for genre in top_five_genres}
print(replacements)
filtered_data = data[data['genre'].isin(top_five_genres)]

for genre, index in replacements.items():
    filtered_data['genre'] = filtered_data['genre'].replace(genre, index)

filtered_data.to_csv("data/genre_labelled_data.csv")
# print(filtered_data['genre'])
# print(len(data), len(filtered_data))

counts = data['genre'].value_counts(ascending=False)

counts= data[data['genre'].isin(top_five_genres)]['genre'].value_counts()
top_counts= data[data['genre'].isin(top_10)]['genre'].value_counts(ascending=False)
bott_counts= data[data['genre'].isin(bott_10)]['genre'].value_counts(ascending=False)


combined = pd.concat([top_counts, bott_counts])
# combined = combined[::-1]

# Define colors and textures
colors = ['orange'] * 10 + ['skyblue'] * 10
hatches = [''] * 10 + ['//'] * 10  # texture for bottom 10

# Create plot
fig, ax = plt.subplots(figsize=(10, 8))
bars = ax.barh(combined.index, combined.values, color=colors, edgecolor='black')

# Apply hatching
for i, bar in enumerate(bars):
    bar.set_hatch(hatches[i])

# Add labels
for i, (value, bar) in enumerate(zip(combined.values, bars)):
    ax.text(value + max(combined.values)*0.01,
            bar.get_y() + bar.get_height()/2,
            str(value),
            va='center', ha='left', fontsize=10)

# Axis labels and title
ax.set_xlabel('Count', fontsize=12)
ax.set_xscale('log')
ax.set_ylabel('Genre', fontsize=12)
ax.set_title('Number of Songs for the 10 most and least common genres', fontsize=14, pad=15)
ax.invert_yaxis()

plt.tight_layout()
plt.grid(alpha=0.3)
# matplot2tikz.save('figures/most_and_least_genres.tex')
plt.show()


print()
print(f"Top 10: {counts[:10]}\n\nBottom 10: {counts[-10:]}")