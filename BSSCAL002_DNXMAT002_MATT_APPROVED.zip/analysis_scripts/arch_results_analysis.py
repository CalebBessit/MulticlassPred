# Analyses the results from hyperparameter tuning and prints the best results for all cases tested
# Caleb Bessit
# 21 October 2025

import os
import pandas as pd

descrips = ["Popularity (3 classes)", "Popularity (5 classes)", "Genre prediction"]

file_names = ["popularity","popularity_5","genre_5"]

subsets = ['structural', 'physical','perceptual','metadata']

metrics = ["val_loss","test_accuracy","test_f1","test_bal_acc","train_time_sec"]
metric_index = 0

for i in range(len(descrips)):
    print(f"\nResults for task {descrips[i]}")

    data = pd.read_csv( os.path.join(f"results/arch/autoencoder_tuning_{file_names[i]}.csv") )

    data = data.sort_values(by= metrics[metric_index])
    print(data.head(1))


# Genre subsets

print(f"\n=========== GENRE SUBSET RESULTS ==========")
for subset in subsets:
    print(f"\n\t + For {subset}:")
    data = pd.read_csv( os.path.join(f"results/arch/autoencoder_tuning_genre_5_classes_using_{subset}_genre.csv") )

    data = data.sort_values(by= metrics[metric_index])
    print(data.head(1))


# 3-class popularity
print(f"\n=========== 3-CLASS POPULARITY SUBSET RESULTS ==========")
for subset in subsets:
    print(f"\n\t + For {subset}:")
    data = pd.read_csv( os.path.join(f"results/arch/autoencoder_tuning_popularity_3_classes_using_{subset}.csv") )

    data = data.sort_values(by= metrics[metric_index])
    print(data.head(1))


# 5-class popularity
print(f"\n=========== 5-CLASS POPULARITY SUBSET RESULTS ==========")
for subset in subsets:
    print(f"\n\t + For {subset}:")
    data = pd.read_csv( os.path.join(f"results/arch/autoencoder_tuning_popularity_5_classes_using_{subset}.csv") )

    data = data.sort_values(by= metrics[metric_index])
    print(data.head(1))