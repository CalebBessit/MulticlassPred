# K-nearest neighbours classifier to be used as a baseline
# Matthew Dean and Caleb Bessit
# 15 October 2025

import time
from sklearn.neighbors import KNeighborsClassifier
from utils import load_data, classification_metrics, VERSION
from sklearn.metrics import accuracy_score, balanced_accuracy_score


NUM_CLASSES = 3

# Load training and testing data
if VERSION=="popularity":
    X_train, y_train = load_data("train", NUM_CLASSES)
    X_test, y_test   = load_data("test", NUM_CLASSES)
elif VERSION=="genre":
    X_train, y_train = load_data("train_genre", NUM_CLASSES)
    X_test, y_test   = load_data("test_genre", NUM_CLASSES)

print(f"Using {VERSION} as target.")


# Create the KNN classifier
knn = KNeighborsClassifier(n_neighbors=1000)

# Train the model (it basically stores the training data)
start = time.time_ns()

knn.fit(X_train, y_train)

print(f"\t + KNN took {(time.time_ns()-start)*(10**-9)} seconds to train.")


# Make predictions
y_pred = knn.predict(X_test)


classification_metrics(y_test, y_pred)

# Evaluate accuracy
acc = accuracy_score(y_test, y_pred)
print(f"Accuracy: {acc:.2f}")

# Compute balanced accuracy
bal_acc = balanced_accuracy_score(y_test, y_pred)
print(f"Balanced Accuracy: {bal_acc:.3f}")